<template>
	<main id="Home-page">
		<h1>Home</h1>
		<p>This is the home page</p>
	</main>
</template>